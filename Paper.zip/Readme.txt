The executable file  is downloadable from:
https://drive.google.com/file/d/1ISYpFm6RQTKQ6SMoXbdo-r0hk2Z4KW0Y/view?usp=drive_link

Speech files are 8kHz sampled PCM signed 16 bit per sample,  little-endian mono raw data (no header).  (see example below how to open & play speech files using Goldwave)

Rate        2400    1200    600 bps
Frame      22.5      67.5     90 ms

The executable is CompandentMELPe83fixed.exe, and its usage is as follows:

Usage:
CompandentMELPe83fixed.exe [-e][-p][-f][-q] [-b bit density] [-r rate]
                          [-m mode] -i infile -o outfile

default: Encoding /Decoding at 2.4kbps with Noise Preprocessor and
               PostFilter

[] = optional parameter
          -e --Apply Noise Preprocessor only (no coding)
          -p --Bypass the Noise Preprocessor (before Encoding)
          -f --Bypass the Post Filter
          -q --quiet operation (Suppresses the frame counter display)

          -b --Channel Data Bit Density/Shortword
               06 = 6 bits/word/Shortword (CTF)
               54 = 54 of each 56 bits (default)
               56 = 56 of each 56 bits (packed)

          -r --Encoding Rate
               2400 = MELPe at 2400 bit/sec
               1200 = MELPe at 1200 bit/sec
                600 = MELPe at  600 bit/sec

          -m --Processing Mode
               C = analysis + synthesis
               A = analysis (encoder) only
               S = synthesis (decoder) only
                  (all above with Noise Preprocessor and PostFilter)
               U = transcoding up to 2400 (from 600/1200 bps
                   depending on rate: -r XXXX)
               D = transcoding down from 2400 (to 600/1200 bps
                   depending on rate: -r XXXX)

Required I/O parameters:
          -i IIIII-- Input file name
          -o OOOOO-- Output file name

for example:
CompandentMELPe83fixed.exe -q -b 54 -i tvex -o tvex.s24
would compress & decompress the input speech file 'tvex' to output
speech file 'tvex.s24' using 2400 bps MELPe and no intermediate messages
would be displayed on screen during processing.

Other options:
CompandentMELPe83fixed.exe -q -b 54 -r 1200 -i tvex -o tvex.s12
CompandentMELPe83fixed.exe -q -b 54 -r 600 -i tvex -o tvex.s06

Note: Analysis=Encoding  / Synthesis=Decoding

You may open and play the I/O speech files using Goldwave.  In Goldwave, open file tvex.in and select the following file format:



Then it should open like the following, and then you can play it or save it as WAV etc.:


Note, it's 2:16 minutes long.  If it sounds right then you are OK.